package ryerson.lab4.business;

import ryerson.lab4.helper.Movie;
import ryerson.lab4.persistence.Movie_CRUD;
import java.util.Collection;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

public class SearchBusiness {

    public Collection<Movie> getMoviesByQuery(String query) {
        Set<Movie> movies = Movie_CRUD.searchMovies(query);
        Map<String, Movie> uniqueMovies = new HashMap<>();

        for (Movie movie : movies) {
            uniqueMovies.put(movie.getMovieName(query), movie);
        }

        return uniqueMovies.values();
    }
}
