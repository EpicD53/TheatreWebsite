/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ryerson.lab4.persistence;

/**
 *
 * @author saadusmani
 */
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import ryerson.lab4.helper.Movie;
import java.sql.Date;
import java.util.HashSet;
import java.util.Set;

public class Movie_CRUD {
    
     private static Connection getCon(){
        Connection con=null;
        try{
            Class.forName("com.mysql.cj.jdbc.Driver");
            con=DriverManager.getConnection("jdbc:mysql://localhost:3306/LMS?zeroDateTimeBehavior=CONVERT_TO_NULL","root","student123");
            System.out.println("Connection established.");
        }catch(Exception e){System.out.println(e + "DENIED");}
        return con;
    }
     
        public static Movie read(String username, String password){
        Movie bean=null;
 
        return bean;
    }
        public static Set<Movie> searchMovies(String query) {
        Set<Movie> matchedMovies = new HashSet<>();
        Connection con = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        try {
            con = getCon();
            String sql = "SELECT * FROM MOVIE WHERE movie_name LIKE ?";
            ps = con.prepareStatement(sql);
            ps.setString(1, "%" + query + "%"); // Using LIKE for SQL pattern matching
            rs = ps.executeQuery();

            while (rs.next()) {
                // Assuming you have a constructor in Movie class that maps database row to Movie object
                Movie movie = new Movie(
                        rs.getString("movie_name"),
                        rs.getInt("capacity"),
                        rs.getInt("age_rating"),
                        rs.getDate("screening_date"),
                        rs.getString("genre"),
                        rs.getString("viewing_option")
                );
                matchedMovies.add(movie);
            }
        } catch (Exception e) {
            e.printStackTrace(); // Log or handle the exception appropriately
        } finally {
            // Close resources (ResultSet, PreparedStatement, Connection)
            try {
                if (rs != null) rs.close();
                if (ps != null) ps.close();
                if (con != null) con.close();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return matchedMovies;
    }
    
    public static Movie create(String movieName, int capacity, int age_rating, Date screening_date, String genre, String viewing_option) {
        Movie bean = null;
        
            try {
            Connection con = getCon();
            String q = "INSERT INTO MOVIE (movie_name, capacity, age_rating, screening_date, genre, viewing_option) VALUES (?, ?, ?, ?, ?, ?)";
            PreparedStatement ps = con.prepareStatement(q);
            ps.setString(1, movieName);
            ps.setInt(2, capacity);
            ps.setInt(3, age_rating);
                java.sql.Date sqlDate = new java.sql.Date(screening_date.getTime()); //
            ps.setDate(4,sqlDate);
            ps.setString(5, genre);
            ps.setString(6, viewing_option);

            ps.executeUpdate();
            
            bean = new Movie(movieName, capacity, age_rating, screening_date, genre, viewing_option);

        } catch (Exception e) {
            e.printStackTrace();
            System.out.println(e + "create method didn't work");
        }
        return bean;
    }
}
